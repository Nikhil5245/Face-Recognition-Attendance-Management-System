from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from employee import Employee
import os
from face_recognisation import Face_recognition
from typing import Union

from fastapi import FastAPI

app = FastAPI()


@app.get("/")
def read_root():
    return {"Welcome": "To Your World"}


@app.get("/items/{item_id}")
def read_item(item_id: int, q: Union[str, None] = None):
    return {"item_id": item_id, "q": q}

class Face:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1580x700+0+0")
        self.root.title("Face")
        img=Image.open("E:\MY SPACE\IMAGE\WALLPAPER 2\ws_Breaking_Bad_Artwork_2560x1440 (1).jpg")
        img=img.resize((1500,710), Image.ANTIALIAS) 
        self.photoimg=ImageTk. PhotoImage(img)

        bg=Label(self.root, image=self.photoimg)

        bg.place(x=0,y=0,width=1530, height=710)
        
        title = Label(text= "Face Recognition attendance",font=("times new roman",40,"bold"),bg="white",fg="blue")
        title.place(x=0,y=0,width=1500,height=80)
        
        #employee details
        img4=Image.open(r"E:\MY SPACE\IMAGE\Lappi Wallpaper\New folder\breaking_bad.jpg") 
        img4=img4.resize((220,220), Image.ANTIALIAS) 
        self.photoimg4=ImageTk. PhotoImage(img4)

        b1=Button(bg,image=self.photoimg4,command=self.Employee_details, cursor="hand2") 
        b1.place(x=200,y=100, width=220,height=220)

        b1_1=Button(bg,text="Employee Details", cursor= "hand2", font=("times new roman", 15, "bold"), bg="green",fg="black")
        b1_1.place(x=200,y=300, width=220,height=40)
        
        #Detect face
        img5=Image.open(r"E:\MY SPACE\IMAGE\Lappi Wallpaper\New folder\face-600x900.png") 
        img5=img5.resize((220,220), Image.ANTIALIAS) 
        self.photoimg5=ImageTk. PhotoImage(img5)

        b2=Button(bg,image=self.photoimg5, cursor="hand2",command=self.face_data) 
        b2.place(x=500,y=100, width=220,height=220)

        b2_1=Button(bg,text="Face Detect", cursor= "hand2", font=("times new roman", 15, "bold"), bg="green",fg="black")
        b2_1.place(x=500,y=300, width=220,height=40)
        
        #Attendance 
        img6=Image.open(r"E:\MY SPACE\IMAGE\Lappi Wallpaper\New folder\Best-attendance-tracking-software.jpg") 
        img6=img6.resize((220,220), Image.ANTIALIAS) 
        self.photoimg6=ImageTk. PhotoImage(img6)

        b2=Button(bg,image=self.photoimg6, cursor="hand2") 
        b2.place(x=800,y=100, width=220,height=220)

        b2_1=Button(bg,text="Attendance", cursor= "hand2", font=("times new roman", 15, "bold"), bg="green",fg="black")
        b2_1.place(x=800,y=300, width=220,height=40)
        
        
        
        
    #function
    def Employee_details(self):
        self.new=Toplevel(self.root)
        self.app=Employee(self.new)
        
    def face_data(self):
        self.new=Toplevel(self.root)
        self.app=Face_recognition(self.new)
    
    
    
        
if __name__=="__main__":
    root=Tk()
    ob=Face(root)
    root.mainloop()
    

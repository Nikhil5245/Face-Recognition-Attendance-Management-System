from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import cv2


class Employee:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1580x700+0+0")
        self.root.title("Face")
        
        #var
        self.var_name=StringVar()
        self.var_Id=StringVar()
        self.var_dep=StringVar()
        self.var_eid=StringVar()
        
        img=Image.open("E:\MY SPACE\IMAGE\WALLPAPER 2\ws_Breaking_Bad_Artwork_2560x1440 (1).jpg")
        img=img.resize((1500,710), Image.ANTIALIAS) 
        self.photoimg=ImageTk. PhotoImage(img)

        bg=Label(self.root, image=self.photoimg)
        bg.place(x=0,y=0,width=1530, height=710)
        
        title = Label(bg,text= "Employee Management system",font=("times new roman",30,"bold"),bg="white",fg="blue")
        title.place(x=0,y=0,width=1500,height=60)
        
        mainf=Frame(bg,bd=2)
        mainf.place(x=15,y=90,width=1500,height=600)
        
        #left
        Left=LabelFrame(mainf,bd=2,bg="white",relief=RIDGE,text="Fill Employee Details",font=("times new roman",15,"bold"))
        Left.place(x=10,y=10,width=590,height=530)
        
        #Name
        name=Label(Left,text="Name",font=("times new roman",12,"bold"),bg="white")
        name.grid(row=0,column=0,padx=10)
        name_entry=ttk.Entry(Left,width=30,textvariable=self.var_name,font=("times new roman",12,"bold"))
        name_entry.grid(row=0,column=1,padx=2,pady=10,sticky=W)
        
         #Employee id
        ID=Label(Left,text="EmployeeID",font=("times new roman",12,"bold"),bg="white")
        ID.grid(row=1,column=0,padx=10)
        ID_entry=ttk.Entry(Left,width=30,textvariable=self.var_Id,font=("times new roman",12,"bold"))
        ID_entry.grid(row=1,column=1,padx=2,pady=10,sticky=W)
        
        #department
        depl=Label(Left,text="Department",font=("times new roman",12,"bold"),bg="white")
        depl.grid(row=2,column=0,padx=10)
        dep=ttk.Combobox(Left,textvariable=self.var_dep,font=("times new roman",15,"bold"),state="readonly",width=17)
        dep["values"]=("Select","JAVA","Python","Cyber Security","Cloud","Main Frame")
        dep.current(0)
        dep.grid(row=2,column=1,padx=2,pady=10)
        
         #Email id
        EID=Label(Left,text="Email-ID",font=("times new roman",12,"bold"),bg="white")
        EID.grid(row=3,column=0,padx=10)
        EID_entry=ttk.Entry(Left,textvariable=self.var_eid,width=30,font=("times new roman",12,"bold"))
        EID_entry.grid(row=3,column=1,padx=2,pady=10,sticky=W)
        
        #radio btn
        self.var_rad1=StringVar()
        take=ttk.Radiobutton(Left,variable=self.var_rad1,text="Take Photo",value="Yes")
        take.grid(row=4,column=0,pady=10)
        
        notake=ttk.Radiobutton(Left,text="No Photo",variable=self.var_rad1,value="No")
        notake.grid(row=4,column=1,pady=10)
        
        #button frame
        btn=Frame(Left,bd=2,relief=RIDGE,bg="white")
        btn.place(x=10,y=300,width=560,height=100)
        
        save=Button(btn,text="Save",command=self.add,width=30,font=("times new roman",12,"bold"),bg="blue",fg="white")
        save.grid(row=0,column=0)
        
        update=Button(btn,text="Update",command=self.update,width=30,font=("times new roman",12,"bold"),bg="blue",fg="white")
        update.grid(row=0,column=1)
        
        delete=Button(btn,text="Delete",command=self.delete,width=30,font=("times new roman",12,"bold"),bg="blue",fg="white")
        delete.grid(row=1,column=0)
        
        reset=Button(btn,text="Reset",command=self.reset,width=30,font=("times new roman",12,"bold"),bg="blue",fg="white")
        reset.grid(row=1,column=1)
        
        take_photo=Button(btn,command=self.generate,text="Take Photo Sample",width=30,font=("times new roman",12,"bold"),bg="blue",fg="white")
        take_photo.grid(row=2,column=0)
        
        update_photo=Button(btn,text="Update Photo Sample",width=30,font=("times new roman",12,"bold"),bg="blue",fg="white")
        update_photo.grid(row=2,column=1)
        
        #right
        Right=LabelFrame(mainf,bd=2,bg="white",relief=RIDGE,text="Employee Details",font=("times new roman",15,"bold"))
        Right.place(x=610,y=10,width=600,height=530)
        
        search=LabelFrame(Right,bd=2,bg="white",fg="red",relief=RIDGE,text="Search System",font=("times new roman",15,"bold"))
        search.place(x=5,y=10,width=590,height=100)
        
        searchby=Label(search,bd=2,bg="purple",fg="white",relief=RIDGE,text="Search By:",font=("times new roman",13,"bold"))
        searchby.grid(row=1,column=0,padx=10,pady=10,sticky=W)
        
        search_c=ttk.Combobox(search,font=("times new roman",15,"bold"),state="readonly",width=13)
        search_c["values"]=("Select","Name","EmpoyeeID","Department")
        search_c.current(0)
        search_c.grid(row=1,column=1,padx=2,pady=10)
        
        searchB=Button(search,text="ShowAll",width=15,font=("times new roman",12,"bold"),bg="blue",fg="white")
        searchB.grid(row=1,column=2,padx=2,pady=10)
        show=Button(search,text="ShowAll",width=15,font=("times new roman",12,"bold"),bg="blue",fg="white")
        show.grid(row=1,column=3,padx=2,pady=10)
        
        #table
        table=Frame(Right,bd=2,bg="white",relief=RIDGE)
        table.place(x=5,y=130,width=580,height=350)
        
        scrollx=ttk.Scrollbar(table,orient=HORIZONTAL)
        scrolly=ttk.Scrollbar(table,orient=VERTICAL)
        
        self.Employee=ttk.Treeview(table,columns=("Name","Employee Id","Department","EmailID","Photo"))
        
        scrollx.pack(side=BOTTOM,fill=X)
        scrolly.pack(side=RIGHT,fill=Y)
        scrollx.config(command=self.Employee.xview)
        scrolly.config(command=self.Employee.yview)
        
        self.Employee.heading("Name",text="Name")
        self.Employee.heading("Employee Id",text="Employee-ID")
        self.Employee.heading("Department",text="Department")
        self.Employee.heading("EmailID",text="Email-ID")
        self.Employee.heading("Photo",text="PhotoStatus")
        self.Employee["show"]="headings"
        
        self.Employee.column("Name",width=100)
        self.Employee.column("Employee Id",width=100)
        self.Employee.column("Department",width=100)
        self.Employee.column("EmailID",width=100)
        
        self.Employee.pack(fill=BOTH,expand=1)
        self.Employee.bind("<ButtonRelease>",self.get_cur)
        self.fetch()
        
        
    #function
    def add(self):
        if self.var_name.get()=="" or self.var_dep.get()=="Select" or self.var_eid.get()=="" or self.var_Id.get()=="":
            messagebox.showerror("Error","All Fields are required",parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(host="localhost",username="root",password="Nikhil9042@",database="face_recognizer")
                mycursor=conn.cursor()
                mycursor.execute("insert into employee values(%s,%s,%s,%s,%s)",(
                                                                                self.var_name.get(),
                                                                                self.var_eid.get(),
                                                                                self.var_dep.get(),
                                                                                self.var_Id.get(),
                                                                                self.var_rad1.get()
                                                                                
                                                                                        ))
                conn.commit()
                self.fetch()
                conn.close()
                messagebox.showinfo("Success","Employee details added Successfully",parent=self.root)
            except Exception as es:
                messagebox.showerror("Error",f"Due To :{str(es)}",parent=self.root)
                
    #fetch
    def fetch(self):
        conn=mysql.connector.connect(host="localhost",username="root",password="Nikhil9042@",database="face_recognizer")
        mycursor=conn.cursor()
        mycursor.execute("select * from employee")
        data=mycursor.fetchall()
        
        if len(data)!=0:
            self.Employee.delete(*self.Employee.get_children())
            for i in data:
                self.Employee.insert("",END,values=i)
            conn.commit()
        conn.close()
    #get 
    def get_cur(self,ev=""):
        curs=self.Employee.focus()
        content=self.Employee.item(curs)
        data=content["values"]
        
        self.var_name.set(data[0]),
        self.var_Id.set(data[1]),
        self.var_dep.set(data[2]),
        self.var_eid.set(data[3]),
        self.var_rad1.set(data[4])
        
    #update
    def update(self):
        if self.var_name.get()=="" or self.var_dep.get()=="Select" or self.var_eid.get()=="" or self.var_Id.get()=="":
            messagebox.showerror("Error","All Fields are required",parent=self.root)
        else:
            try:
                Update=messagebox.askyesno("Update","Do you want pdate the Employee Details",parent=self.root)
                if Update>0:
                    conn=mysql.connector.connect(host="localhost",username="root",password="Nikhil9042@",database="face_recognizer")
                    mycursor=conn.cursor()
                    mycursor.execute("update employee set Name=%s,Employee Id=%s,Department=%s,EmailId=%s,PhotoSample=%s where Employee ID=%s",(
                                                            
                                                            self.var_name.get(),
                                                            self.var_dep.get(),
                                                            self.var_eid.get(),
                                                            self.var_rad1.get(),
                                                            self.var_Id.get()
                                                            
                                                            ))
                else:
                    if not Update:
                        return
                messagebox.showinfo("Success","Employee Details Updated Successfully",parent=self.root)
                conn.commit()
                self.fetch()
                conn.close()
            except Exception as es:
                messagebox.showerror("Error",f"Due To :{str(es)}",parent=self.root)
        
    #delete
    def delete(self):
        if self.var_Id.get()=="":
            messagebox.showerror("Error","Employee Must be Required",parent=self.root)
        else:
            try:
                delete=messagebox.askyesno("Delete Employee Details","Do want to Delete this detail",parent=self.root)
                if delete>0:
                    conn=mysql.connector.connect(host="localhost",username="root",password="Nikhil9042@",database="face_recognizer")
                    mycursor=conn.cursor()
                    sql="delete from employee where EmployeeID=%s"
                    val=(self.var_Id.get(),)
                    mycursor.execute(sql,val)
                else:
                    if not delete:
                        return
        
                conn.commit()
                self.fetch()
                conn.close()
                messagebox.showinfo("Delete","Employee Details Deleted Successfully",parent=self.root)
            except Exception as es:
                messagebox.showerror("Error",f"Due To :{str(es)}",parent=self.root)
    
    #reset
    def reset(self):
        self.var_name.set("")
        self.var_Id.set("")
        self.var_dep.set("Select")
        self.var_eid.set("")
        self.var_rad1.set("")
    
    
    # generate data set
    def generate(self):
        if self.var_name.get()=="" or self.var_dep.get()=="Select" or self.var_eid.get()=="" or self.var_Id.get()=="":
            messagebox.showerror("Error","All Fields are required",parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(host="localhost",username="root",password="Nikhil9042@",database="face_recognizer")
                mycursor=conn.cursor()
                mycursor.execute("Select * from employee")
                result=mycursor.fetchall()
                id=0
                for x in result:
                    id+=1
                    mycursor.execute("update employee set Name=%s,EmployeeID=%s,Department=%s,EmailId=%s,Photo=%s where EmployeeID=%s",(
                                                            
                                                            self.var_name.get(),
                                                            self.var_dep.get(),
                                                            self.var_eid.get(),
                                                            self.var_rad1.get(),
                                                            self.var_Id.get()==id+1
                                                            
                                                            ))
                    conn.commit()
                    self.fetch()
                    self.reset()
                    conn.close()
                    
                    
                    #frontal face
                    face=cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
                    
                    def face_crp(img):
                        grey=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
                        faces=face.detectMultiScale(grey,1,3,5)
                        
                        for (x,y,w,h) in faces:
                            face_crp=img[y:y+h,x:x+w]
                            return face_crp
                    
                    cap=cv2.VideoCapture(0)
                    img_id=0
                    while True:
                        ret,my_frame=cap.read()
                        if face_crp(my_frame) is not None:
                            img_id+=1
                        face=cv2.resize(face_crp(my_frame),(450,450))
                        face=cv2.cvtColor(face,cv2.COLOR_BGR2GRAY)
                        file_name="Image/emp."+str(id)+"."+str(img_id)+".jpg"
                        cv2.imwrite(file_name,face)
                        cv2.putText(face.str(img_id),(50,50),cv2.FONT_HERSHEY_COMPLEX,2,(0,255,0),2)
                        cv2.imshow("Crooped Face",face)
                        
                        if cv2.waitKey(1)==13 or int(img_id)==100:
                            break
                    cap.release()
                    cv2.destroyAllWindows()
                    messagebox.showinfo("Result","Generating data sets completed!!!")
            except Exception as es:
                messagebox.showerror("Error",f"Due To :{str(es)}",parent=self.root)
                    
                            
if __name__=="__main__":
    root=Tk()
    ob=Employee(root),      
    root.mainloop()
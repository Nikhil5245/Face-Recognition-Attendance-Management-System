if __name__=="__main__":
    root=Tk()
    ob=Face(root)
    root.mainloop()
    
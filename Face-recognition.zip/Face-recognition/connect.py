from sqlite3 import connect
import mysql.connector

con=mysql.connector.connect(host='localhost',username='root',password='Nikhil9042@',database='niksak')

myc=con.cursor()
con.commit()
con.close()
print("connected")
from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from employee import Employee
import mysql.connector
from time import strftime
from datetime import datetime
import os
import cv2

class Face_recognition:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1580x700+0+0")
        self.root.title("Face Recognition System")
        
        title = Label(text= "Face Recognition ",font=("times new roman",40,"bold"),bg="white",fg="blue")
        title.place(x=0,y=0,width=1500,height=80)
        
        img=Image.open(r"E:\MY SPACE\IMAGE\WALLPAPER 2\ws_Breaking_Bad_Artwork_2560x1440 (1).jpg")
        img=img.resize((1500,710), Image.ANTIALIAS) 
        self.photoimg=ImageTk.PhotoImage(img)
        
        Right = Label(self.root,image=self.photoimg)
        Right.place(x=750,y=90,width=500,height=530)
        
        Left = Label(self.root,image=self.photoimg)
        Left.place(x=50,y=90,width=700,height=530)
        
        b1_1=Button(Left,text="Face Recognition", cursor= "hand2", font=("times new roman", 15, "bold"), bg="green",fg="black")
        b1_1.place(x=220,y=400, width=220,height=40)
        
        #attendance 
    def mark_att(self,E,i,D):
        with open("atten.csv","r+",newline="\n") as f:
            mydataList=f.readlines();
            name_l=[]
            for line  in mydataList:
                entry=line.split((",")) 
                name_l.append(entry[0])
            if((E not in name_l) and (i not in name_l) and (D not in name_l)):
                now=datetime.now()
                d1=now.strftime("%d/%m/%Y")
                dtStr=now.strftime("%H:%M:%S")
                f.writelines(f"\n{E},{i},{D},{dtStr},{d1},Preset")
            
        
        
    def face_rec(self):
        def draw(img,classifier,scaleFactor,min,color,text,clf):
            grey=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
            feat=classifier.detect(grey,scaleFactor,min)
            
            cord=[]
            
            for (x,y,w,h) in feat:
                cv2.rectangle(img(x,y),(x+w,y+h),(0,255,0),3)
                id,predict=clf.predict(grey[y:y+h,x:x+w])
                confi=int((100*(1-predict/300)))
                
                conn=mysql.connector.connect(host="localhost",username="root",password="Nikhil9042@",database="face_recognizer")
                mycursor=conn.cursor()
                
                mycursor.execute("select Name from employee where EmployeeID="+str(id))
                i=mycursor.fetchone()
                i="+".join(i)
                
                mycursor.execute("select Employee Id from employee where Employee Id="+str(id))
                E=mycursor.fetchone()
                E="+".join(E)
                
                mycursor.execute("select Department from employee where EmployeeID="+str(id))
                D=mycursor.fetchone()
                D="+".join(D)
                
                if confi>77:
                    cv2.putText(img,f"Employee Id:{E}",(x,y-55),cv2.FONT_HERSHEY_COMPLEX,0.8,(255,255,255),3)
                    cv2.putText(img,f"Name:{i}",(x,y-30),cv2.FONT_HERSHEY_COMPLEX,0.8,(255,255,255),3)
                    cv2.putText(img,f"Department:{D}",(x,y-5),cv2.FONT_HERSHEY_COMPLEX,0.8,(255,255,255),3)
                    self.mark_att(E,i,D)
                else:
                    cv2.rectangle(img(x,y),(x+w,y+h),(0,0,255),3)
                    cv2.putText(img,f"Unknown Person",(x,y-5),cv2.FONT_HERSHEY_COMPLEX,0.8,(255,255,255),3)
                    
                cord=[x,y,w,h]
            return cord
        def reco(img,clf,faceCascade):
            cord=draw(img,faceCascade,1.1,10,(255,255,255),"Face",clf)
            return img
        
        faceCascade=cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
        clf= cv2.face.LBPHFaceRecognizer_create()
        #clf.read("")
        
        video=cv2.VideoCapture(0)
        
        while True:
            ret,img=video.read()
            cv2.imshow("Welcome To face Recognition",img)
            
            if cv2.waitKey(1)==13:
                break
            video.release()
            cv2.destroyAllWindows()
        
        
        
        
        


if __name__=="__main__":
    root=Tk()
    ob=Face_recognition(root)
    root.mainloop()
    